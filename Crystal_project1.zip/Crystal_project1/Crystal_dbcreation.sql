﻿CREATE DATABASE Asos;
GO

USE Asos;
GO

--Create Tables--
CREATE TABLE Brand(
BrandID bigint NOT NULL PRIMARY KEY,
Name varchar(50) NOT NULL,
BrandDescription varchar(MAX) NOT NULL);

CREATE TABLE Product(
ProductID bigint NOT NULL PRIMARY KEY,
BrandID bigint NOT NULL,
Name varchar(50) NOT NULL,
Cost float NOT NULL,
Price float NOT NULL,
Size varchar(20) NOT NULL,
ProductDescription varchar(200) NOT NULL,
Color varchar(20) NOT NULL);

CREATE TABLE OrderItems(
OrderItemsID bigint NOT NULL PRIMARY KEY,
SalesOrderID bigint NOT NULL,
ProductID bigint NOT NULL,
OrderQuantity bigint NOT NULL,
UnitPrice float NOT NULL,
LineTotal float NOT NULL);

CREATE TABLE SalesOrder(
SalesOrderID bigint NOT NULL PRIMARY KEY,
CustomerID bigint NOT NULL,
CreditCardID bigint NOT NULL,
OrderDate date,
Subtotal float NOT NULL,
Tax float NOT NULL,
TotalAmount float NOT NULL);

CREATE TABLE CreditCard(
CreditCardID bigint NOT NULL PRIMARY KEY,
CreditCardNumber bigint NOT NULL,
ExpirationDate date NOT NULL,
BillingAddress varchar(100) NOT NULL);

CREATE TABLE Customer(
CustomerID bigint NOT NULL PRIMARY KEY,
CountryID bigint NOT NULL,
FirstName varchar(50) NOT NULL,
LastName varchar(50) NOT NULL,
EmailAddress varchar(50) NOT NULL,
PhoneNumber bigint NOT NULL,
CustomerAddress varchar(50) NOT NULL);

CREATE TABLE Country(
CountryID bigint NOT NULL PRIMARY KEY,
Name varchar(50) NOT NULL,
Region varchar(50) NOT NULL);

--Create Relationships--
ALTER TABLE Product ADD CONSTRAINT FK_Product_Brand 
FOREIGN KEY (BrandID) REFERENCES Brand(BrandID);

ALTER TABLE OrderItems ADD CONSTRAINT FK_OrderItems_SalesOrder
FOREIGN KEY (SalesOrderID) REFERENCES SalesOrder(SalesOrderID);

ALTER TABLE OrderItems ADD CONSTRAINT FK_OrderItems_Product
FOREIGN KEY (ProductID) REFERENCES Product(ProductID);

ALTER TABLE SalesOrder ADD CONSTRAINT FK_SalesOrder_Customer
FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID);

ALTER TABLE SalesOrder ADD CONSTRAINT FK_SalesOrder_CreditCard
FOREIGN KEY (CreditCardID) REFERENCES CreditCard(CreditCardID);

ALTER TABLE Customer ADD CONSTRAINT FK_Customer_Country
FOREIGN KEY (CountryID) REFERENCES Country(CountryID);

--Add Data--
INSERT INTO Brand (BrandID, Name, BrandDescription) VALUES
(1, 'Asos', 'Whatever your denim and dresses DNA, our ASOS own-label collection has you covered.'),
(2, 'Boohoo', 'Life is a party, dress like it.'),
(3, 'Cheap Monday', 'Giving us lessons in Scandi style, Stockholm-based label Cheap Monday are known for their perfect fit skinny jeans.'),
(4, 'Dr. Martens', 'These are the people who stand out from the crowd and their journey of self-expression has always been accompanied by a pair of DMs.'),
(5, 'French Connection', 'French Connection crafts an agenda-setting wardrobe that is worn with ease for SS17.'),
(6, 'Jack Wills', 'Jack Wills launched in 1999 in Salcombe, Devon, designing British heritage-inspired goods for the university crowd.'),
(7, 'Mango', 'With a youthful spirit and a modern philosophy, the designs personify the latest trends.'),
(8, 'River Island', 'Print is key to River Island this season, with stripes and florals throughout.'),
(9, 'Weekday', 'Weekday founders Örjan Andersson and Adam Friberg honed their signature Scandi style across a cult line of skinny jeans.'),
(10, 'Vero Moda', 'Reboot your wardrobe this SS16 with Danish brand VERO MODA.');

INSERT INTO Product (ProductID, BrandID, Name, Cost, Price, Size, ProductDescription, Color) VALUES
(1,1, 'A-Line Mini Skirt with Scallop Hem', 18, 31, 'Medium', 'Woven fabric. High-rise waist.', 'Mint'),
(2,1, 'Linen Cigarette Pants', 24, 34, 'Small', 'Linen-rich woven fabric. Tapered leg.','Teal'),
(3,2, 'Eyelet Lace Plunging Midi Dress', 46, 62, 'Small', 'Sheer lace. Mini-length lining.', 'Ivory'),
(4,2, 'Contrast Band T-shirt', 16, 32, 'Large', 'Soft-touch jersey.', 'Black'),
(5,3, 'Standard T-Shirt Corpse Skull', 27, 35, 'Medium', 'Crew neck. Short sleeves.', 'Deep Red'),
(6,3, 'Tight Jean Sky Wash', 48, 90, 'Small', 'Firm-stretch denim.','Sky'),
(7,4, 'Charlotte Shoe', 59, 78, '6', 'Leather upper. Brogue detail.', 'Tan'),
(8,4, 'Pascal 8 Eye Boots', 68, 131, '8', 'Leather upper. Contrast stitching.', 'Black Leather'),
(17,5, 'Lula Stretch Bodycon Color Block Dress', 67, 83, 'Medium', 'V-neckline.', 'Black'),
(9,5,  'Florrie Drape Top', 29, 32, 'Large', 'Sleeveless cut. Round neckline.', 'Apricot Spritz'),
(10,6, 'Oxford Shirt', 33, 90, 'Large', 'Breathable cotton. Embroidered logo.', 'Sky blue'),
(11,6, 'Cratfield Wax Jacket', 94, 149, 'Small', 'Waxed woven outer. fully lined.', 'Olive'),
(12,7, 'Stripe Wrap Front Jumpsuit', 45, 91, 'Small', 'Striped fabric. Self-tie waist belt', 'Multi'), 
(13,8, 'Ribbed High Neck Sweater Dress', 19, 37, 'Medium', 'Ribbed woven fabric', 'Gray'),
(14,9, 'Anorak Jacket', 55, 76, 'Small', 'Concealed placket. Drawstring hood', 'Black'),
(15,9, 'Alex T-shirt', 9, 12, 'Medium', 'Marl jersey. Scoop neck.', 'Gray'),
(16,10, 'Embroidered Mini Skirt', 33, 43, 'Large', 'A-line.', 'Multi');

INSERT INTO Country (CountryID, Name, Region) VALUES
(1, 'United Kingdom', 'Europe'),
(2, 'United States', 'North America'),
(3, 'France', 'Europe'),
(4, 'Germany', 'Europe'),
(5, 'Italy', 'Europe'),
(6, 'Australia', 'Australia'),
(7, 'Spain', 'Europe'),
(8, 'Russia', 'Asia'),
(9, 'China', 'Asia'),
(10, 'Canada', 'North America');

INSERT INTO Customer (CustomerID, CountryID, FirstName, LastName, EmailAddress, PhoneNumber, CustomerAddress) VALUES
(1,5, 'Karen', 'Smith', 'ksmith@gmail.com', 6469327842, '12 Chimney Road'),
(2,7,'Chris','Lang', 'clang@aol.com', 9013227060, '1004 Real Road'),
(3,8,'Phil', 'Gallagher', 'lipgallagher@gmail.com', 2163430661, '85 Main Street'),
(4,9,'Mandy', 'Malkovich', 'mandym@yahoo.com', 6341243654, '214 Allen Street'),
(5,2,'Pam', 'Halpert', 'phalpert12@gmail.com', 8087053328, '9 Miflin Road'),
(6,1,'Alex', 'White', 'alexw@gmail.com', 7323879324, '4 Abbey Avenue'),
(7,3,'Emma', 'Day', 'emmaday@yahoo.com', 3123907077, '96 Broadway Street'),
(8,6,'Lois', 'Cleavers', 'loisc@gmail.com', 8203658294, '490 Lincoln Street'),
(9,4,'Ali', 'Peters', 'alip@gmail.com', 3749248583, '32 Trpisovsky Court'),
(10,7,'Steve', 'Clemmons', 'sclemmons@gmail.com', 8362749203, '120 Eggard Street');

INSERT INTO CreditCard (CreditCardID, CreditCardNumber, ExpirationDate, BillingAddress) VALUES
(1, 203748391757, '2021-10-30', '9 Miflin Road'), 
(2, 379263376012, '2018-02-28', '1004 Real Road'),
(3, 193759321758, '2019-05-30', '32 Trpisovsky Court'),
(4, 601185934729, '2017-07-30', '490 Lincoln Street'),
(5, 483944920385, '2022-01-30', '12 Chimney Road'),
(6, 927581038574, '2020-03-30', '4 Abbey Avenue'),
(7, 278394289873, '2018-11-30', '96 Broadway Street'),
(8, 328176073941, '2017-12-30', '214 Allen Street'),
(9, 801274968927, '2019-06-30', '85 Main Street'),
(10, 83639205738, '2018-04-30', '120 Eggard Street');

INSERT INTO SalesOrder (SalesOrderID, CustomerID, CreditCardID, OrderDate, Subtotal, Tax, TotalAmount) VALUES
(1,4,10, '2016-01-04', 107,20,127.00),
(2,7,6, '2016-02-01',90,17.10,107.10),
(3,2,2, '2016-02-01',78,14.04,92.04),
(4,4,7,'2016-03-30', 91,0,91.00),
(5,6,1, '2016-09-12', 152,10.64,162.64),
(6,8,5, '2016-10-07', 131,13.10,144.10),
(7,10,8, '2017-01-04', 149,26.82,175.82),
(8,9,3, '2017-02-16', 31,5.89, 36.89),
(9,1,9, '2017-04-01', 94,18.8, 112.8),
(10,3,4, '2017-04-01', 90,16.2, 106.2);


INSERT INTO OrderItems (OrderItemsID, SalesOrderID, ProductID, OrderQuantity, UnitPrice, LineTotal) VALUES
(1,1,10,1,43,43),
(2,1,4,2,32,64),
(3,2,6,1,90,90),
(4,3,7,1,78,78),
(5,4,12,1,91,91),
(6,5,14,2,76,152),
(7,6,8,1,131,131),
(8,7,11,1,149,149),
(9,8,1,1,31,31),
(10,9,3,1,62,62),
(11,9,9,1,32,32),
(12,10,10,1,90,90);
