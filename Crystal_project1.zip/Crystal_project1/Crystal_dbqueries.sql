--Team Name:Crystal --

USE Asos;

--1. Displays all of the records from each table--
SELECT*FROM Brand;
SELECT*FROM Product;
SELECT*FROM SalesOrder;
SELECT*FROM OrderItems;
SELECT*FROM CreditCard;
SELECT*FROM Customer;
SELECT*FROM Country;

--2. Total Amount of Sales and Tax collected--
SELECT sum(TotalAmount) as TotalSales, sum(Tax) as TotalTax
FROM SalesOrder;

--3. Total Number of Orders Placed and Total Amount Spent by Each Customer--
SELECT d.FirstName, d.LastName, count(c.SalesOrderID) as OrderQuantity, sum(TotalAmount) as TotalAmount
FROM Product as a
INNER JOIN OrderItems as b
ON a.ProductID = b.ProductID
INNER JOIN SalesOrder as c
ON b.SalesOrderID = c.SalesOrderID
INNER JOIN Customer as d
ON c.CustomerID = d.CustomerID
GROUP BY d.FirstName, d.LastName;

--3. Total of Each Line of the Order by Each Product and Customer--
SELECT d.FirstName, d.LastName, a.Name as ProductName, b.OrderQuantity as Quantity, b.LineTotal
FROM Product as a
INNER JOIN OrderItems as b
ON a.ProductID = b.ProductID
INNER JOIN SalesOrder as c
ON b.SalesOrderID = c.SalesOrderID
INNER JOIN Customer as d
ON c.CustomerID = d.CustomerID;

UPDATE SalesOrder
SET OrderDate = NULL
WHERE OrderDate = '2016-03-30';

--4. Average Amount Spent in Each Country--
--RIGHT JOIN is needed to only display Countries with Averages which excludes Canada and United States.--
SELECT a.Name, AVG(b.TotalAmount) as AverageTotal
FROM Country as a
JOIN Customer as c
ON a.CountryID = c.CountryID
RIGHT JOIN SalesOrder as b
ON b.CustomerID = c.CustomerID
GRoup BY a.Name;

--5. Total Quantities of Products Purchased in 2016--
SELECT a.Name, sum(b.OrderQuantity) as Quantity
FROM Product as a
JOIN OrderItems as b
ON a.ProductID = b.ProductID
JOIN SalesOrder as c
ON b.SalesOrderID = c.SalesOrderID
WHERE c.OrderDate like '2016%'
GROUP BY a.Name;

